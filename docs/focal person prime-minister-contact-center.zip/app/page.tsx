'use client'

import { useMemo, useState } from 'react'
import {
  Bell,
  BriefcaseBusiness,
  CalendarDays,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  ClipboardList,
  Clock3,
  FileText,
  Filter,
  LayoutDashboard,
  LogOut,
  MapPin,
  Menu,
  MessageSquareText,
  MoreHorizontal,
  PanelLeftClose,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  UserRound,
  UsersRound,
  X,
} from 'lucide-react'

type Complaint = {
  id: string
  citizen: string
  subject: string
  category: string
  district: string
  age: string
  days: number
  status: 'Needs review' | 'In progress' | 'Field visit'
  duplicate?: boolean
  initials: string
}

const complaints: Complaint[] = [
  { id: 'PMCC-2024-008421', citizen: 'Muhammad Saeed', subject: 'Delayed electricity connection', category: 'Energy & power', district: 'Muzaffarabad', age: '2 hours ago', days: 2, status: 'Needs review', duplicate: true, initials: 'MS' },
  { id: 'PMCC-2024-008417', citizen: 'Nadia Yousaf', subject: 'Road damaged after rainfall', category: 'Communication & works', district: 'Bagh', age: '5 hours ago', days: 5, status: 'In progress', initials: 'NY' },
  { id: 'PMCC-2024-008409', citizen: 'Rashid Hussain', subject: 'Missing medicine at BHU', category: 'Health', district: 'Poonch', age: 'Yesterday', days: 9, status: 'Field visit', initials: 'RH' },
  { id: 'PMCC-2024-008395', citizen: 'Shazia Akhtar', subject: 'Water supply interruption', category: 'Public health engineering', district: 'Neelum', age: 'Yesterday', days: 13, status: 'Needs review', duplicate: true, initials: 'SA' },
]

const navItems = [
  { label: 'Overview', icon: LayoutDashboard, active: true },
  { label: 'Complaint queue', icon: ClipboardList, count: '24' },
  { label: 'Field visits', icon: MapPin, count: '6' },
  { label: 'Team', icon: UsersRound },
]

function StatusPill({ status }: { status: Complaint['status'] }) {
  const styles = {
    'Needs review': 'bg-amber-soft text-amber-ink',
    'In progress': 'bg-blue-soft text-blue-ink',
    'Field visit': 'bg-teal-soft text-teal-ink',
  }
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${styles[status]}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{status}</span>
}

function StatCard({ label, value, meta, tone, icon: Icon }: { label: string; value: string; meta: string; tone: string; icon: typeof Clock3 }) {
  return <div className="stat-card">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        <p className="mt-2 text-3xl font-semibold tracking-tight text-foreground">{value}</p>
      </div>
      <div className={`rounded-xl p-2.5 ${tone}`}><Icon className="h-[18px] w-[18px]" /></div>
    </div>
    <p className="mt-4 text-xs text-muted-foreground">{meta}</p>
  </div>
}

export default function Page() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [activeFilter, setActiveFilter] = useState('All complaints')
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null)
  const [search, setSearch] = useState('')

  const visibleComplaints = useMemo(() => complaints.filter((item) => {
    const matchesFilter = activeFilter === 'All complaints' || item.status === activeFilter
    const query = search.toLowerCase()
    return matchesFilter && (!query || `${item.citizen} ${item.subject} ${item.id}`.toLowerCase().includes(query))
  }), [activeFilter, search])

  return <main className="min-h-screen bg-background text-foreground">
    <div className={`sidebar-overlay ${sidebarOpen ? 'is-open' : ''}`} onClick={() => setSidebarOpen(false)} />
    <aside className={`sidebar ${sidebarOpen ? 'is-open' : ''}`}>
      <div className="flex items-center gap-3 px-6 py-7">
        <div className="brand-mark"><ShieldCheck className="h-5 w-5" /></div>
        <div><p className="font-semibold tracking-tight">PMCC</p><p className="text-[10px] uppercase tracking-[0.18em] text-sidebar-muted">Contact Center</p></div>
        <button className="ml-auto rounded-lg p-1 text-sidebar-muted hover:bg-sidebar-hover md:hidden" onClick={() => setSidebarOpen(false)} aria-label="Close navigation"><X className="h-5 w-5" /></button>
      </div>
      <div className="px-3">
        <p className="nav-label">Workspace</p>
        <nav className="space-y-1">
          {navItems.map((item) => <button key={item.label} className={`nav-item ${item.active ? 'active' : ''}`}><item.icon className="h-[18px] w-[18px]" /><span>{item.label}</span>{item.count && <span className="nav-count">{item.count}</span>}</button>)}
        </nav>
        <p className="nav-label mt-9">Manage</p>
        <nav className="space-y-1">
          <button className="nav-item"><MessageSquareText className="h-[18px] w-[18px]" /><span>Messages</span><span className="nav-dot" /></button>
          <button className="nav-item"><Settings className="h-[18px] w-[18px]" /><span>Settings</span></button>
        </nav>
      </div>
      <div className="mt-auto p-3">
        <div className="rounded-2xl bg-sidebar-panel p-3.5">
          <div className="flex items-center gap-3"><div className="avatar avatar-lime">AK</div><div className="min-w-0"><p className="truncate text-sm font-semibold">Ayesha Khan</p><p className="truncate text-xs text-sidebar-muted">Focal Person · Health</p></div><MoreHorizontal className="ml-auto h-4 w-4 text-sidebar-muted" /></div>
        </div>
        <button className="nav-item mt-2 w-full"><LogOut className="h-[18px] w-[18px]" /><span>Sign out</span></button>
      </div>
    </aside>

    <section className="md:ml-[252px]">
      <header className="topbar">
        <button className="rounded-lg p-2 hover:bg-secondary md:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Menu className="h-5 w-5" /></button>
        <div className="hidden items-center gap-2 text-sm text-muted-foreground md:flex"><span>Workspace</span><ChevronRight className="h-4 w-4" /><span className="font-medium text-foreground">Overview</span></div>
        <div className="ml-auto flex items-center gap-2 sm:gap-4"><div className="relative hidden sm:block"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input aria-label="Search complaints" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search complaints" className="search-input" /></div><button className="icon-button relative" aria-label="Notifications"><Bell className="h-[18px] w-[18px]" /><span className="notification-dot" /></button><div className="hidden h-7 w-px bg-border sm:block" /><button className="flex items-center gap-2"><div className="avatar avatar-lime">AK</div><ChevronDown className="hidden h-4 w-4 text-muted-foreground sm:block" /></button></div>
      </header>

      <div className="mx-auto max-w-[1440px] px-5 py-7 sm:px-8 lg:px-10 lg:py-9">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="eyebrow">Tuesday, 24 September 2024</p><h1 className="mt-2 text-3xl font-semibold tracking-tight sm:text-[34px]">Good morning, Ayesha</h1><p className="mt-2 text-sm text-muted-foreground">Here&apos;s what needs your attention today.</p></div><button className="primary-button"><FileText className="h-4 w-4" /> New complaint</button></div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard label="Open complaints" value="24" meta="4 added this week" tone="bg-blue-soft text-blue-ink" icon={ClipboardList} />
          <StatCard label="Needs your review" value="08" meta="2 are nearing SLA" tone="bg-amber-soft text-amber-ink" icon={CircleAlert} />
          <StatCard label="In progress" value="11" meta="Across 4 categories" tone="bg-teal-soft text-teal-ink" icon={Clock3} />
          <StatCard label="Resolved this month" value="37" meta="12% higher than August" tone="bg-lilac-soft text-lilac-ink" icon={ShieldCheck} />
        </div>

        <div className="mt-8 grid gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
          <section className="panel overflow-hidden">
            <div className="flex flex-col gap-4 border-b border-border px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6"><div><h2 className="section-title">Complaint queue</h2><p className="mt-1 text-sm text-muted-foreground">Health department · 24 total complaints</p></div><div className="flex items-center gap-2"><button className="filter-button"><Filter className="h-4 w-4" /> Filter <ChevronDown className="h-3.5 w-3.5" /></button><button className="icon-button border" aria-label="More queue options"><MoreHorizontal className="h-4 w-4" /></button></div></div>
            <div className="flex gap-1 overflow-x-auto border-b border-border px-5 pt-1 sm:px-6">{['All complaints', 'Needs review', 'In progress', 'Field visit'].map((filter) => <button key={filter} onClick={() => setActiveFilter(filter)} className={`tab ${activeFilter === filter ? 'active' : ''}`}>{filter}{filter === 'Needs review' && <span className="tab-badge">8</span>}</button>)}</div>
            <div className="overflow-x-auto"><table className="w-full min-w-[720px] text-left"><thead><tr className="table-head"><th>Complaint</th><th>Category</th><th>Age</th><th>Status</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>{visibleComplaints.map((item) => <tr key={item.id} className="table-row" onClick={() => setSelectedComplaint(item)}><td><div className="flex items-center gap-3"><div className="avatar avatar-blue">{item.initials}</div><div><p className="font-semibold text-foreground">{item.subject}</p><p className="mt-1 text-xs text-muted-foreground">{item.id} · {item.citizen}</p></div></div></td><td><p className="text-sm text-foreground">{item.category}</p><p className="mt-1 text-xs text-muted-foreground">{item.district}</p></td><td><p className={`text-sm font-medium ${item.days >= 10 ? 'text-amber-ink' : 'text-foreground'}`}>{item.age}</p><p className="mt-1 text-xs text-muted-foreground">{item.days} of 15 days</p></td><td><div className="flex flex-wrap items-center gap-2"><StatusPill status={item.status} />{item.duplicate && <span className="inline-flex items-center gap-1 rounded-full bg-lilac-soft px-2 py-1 text-[11px] font-semibold text-lilac-ink"><Sparkles className="h-3 w-3" /> Match found</span>}</div></td><td><ChevronRight className="h-4 w-4 text-muted-foreground" /></td></tr>)}</tbody></table></div>
            <div className="flex items-center justify-between border-t border-border px-5 py-4 sm:px-6"><p className="text-xs text-muted-foreground">Showing {visibleComplaints.length} of 24 complaints</p><button className="text-xs font-semibold text-teal-ink hover:underline">View all complaints <ChevronRight className="ml-1 inline h-3.5 w-3.5" /></button></div>
          </section>

          <aside className="space-y-5">
            <div className="panel p-5"><div className="flex items-center justify-between"><h2 className="section-title">Your focus</h2><button className="text-muted-foreground"><MoreHorizontal className="h-5 w-5" /></button></div><p className="mt-1 text-sm text-muted-foreground">Priorities based on age and status</p><div className="mt-5 space-y-4"><div className="focus-item"><div className="focus-icon bg-amber-soft text-amber-ink"><CircleAlert className="h-4 w-4" /></div><div><p className="text-sm font-semibold">2 complaints near SLA</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Review before they pass the 15-day threshold.</p></div><ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" /></div><div className="focus-item"><div className="focus-icon bg-lilac-soft text-lilac-ink"><Sparkles className="h-4 w-4" /></div><div><p className="text-sm font-semibold">3 duplicate matches</p><p className="mt-1 text-xs leading-5 text-muted-foreground">AI suggestions are waiting for your decision.</p></div><ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" /></div><div className="focus-item"><div className="focus-icon bg-teal-soft text-teal-ink"><MapPin className="h-4 w-4" /></div><div><p className="text-sm font-semibold">6 field visits scheduled</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Next visit is tomorrow in Poonch.</p></div><ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" /></div></div></div>
            <div className="panel p-5"><div className="flex items-start justify-between"><div><h2 className="section-title">Team activity</h2><p className="mt-1 text-sm text-muted-foreground">This week</p></div><UsersRound className="h-5 w-5 text-teal-ink" /></div><div className="mt-5 flex items-end gap-2"><span className="text-3xl font-semibold">82</span><span className="pb-1 text-sm text-muted-foreground">actions completed</span></div><div className="mt-4 h-2 overflow-hidden rounded-full bg-secondary"><div className="h-full w-[72%] rounded-full bg-teal" /></div><div className="mt-3 flex justify-between text-xs text-muted-foreground"><span>72% of weekly goal</span><span>114 target</span></div></div>
            <div className="rounded-2xl bg-ink p-5 text-ink-foreground"><div className="flex items-center gap-2 text-lime"><CalendarDays className="h-4 w-4" /><span className="text-xs font-semibold uppercase tracking-wider">Upcoming</span></div><p className="mt-3 text-sm font-medium">Monthly department review</p><p className="mt-1 text-xs text-ink-muted">Thursday, 26 September · 10:00 AM</p><button className="mt-4 text-xs font-semibold text-lime hover:underline">View calendar <ChevronRight className="ml-1 inline h-3.5 w-3.5" /></button></div>
          </aside>
        </div>
      </div>
    </section>

    {selectedComplaint && <div className="drawer-backdrop" onClick={() => setSelectedComplaint(null)}><div className="complaint-drawer" onClick={(e) => e.stopPropagation()}><div className="flex items-start justify-between"><div><StatusPill status={selectedComplaint.status} /><h2 className="mt-4 text-xl font-semibold">{selectedComplaint.subject}</h2><p className="mt-1 text-sm text-muted-foreground">{selectedComplaint.id}</p></div><button className="icon-button" onClick={() => setSelectedComplaint(null)} aria-label="Close complaint details"><X className="h-5 w-5" /></button></div><div className="mt-8 grid grid-cols-2 gap-4"><div className="detail-box"><p className="detail-label">Citizen</p><p className="detail-value">{selectedComplaint.citizen}</p></div><div className="detail-box"><p className="detail-label">CNIC</p><p className="detail-value">37405-•••••••-1</p></div><div className="detail-box"><p className="detail-label">District</p><p className="detail-value">{selectedComplaint.district}</p></div><div className="detail-box"><p className="detail-label">Open for</p><p className="detail-value">{selectedComplaint.days} days</p></div></div><div className="mt-8"><p className="detail-label">Next step</p><p className="mt-2 text-sm leading-6 text-muted-foreground">Review the complaint and classify it as handle directly, club with existing, forward externally, or schedule a field visit.</p></div><button className="primary-button mt-8 w-full justify-center">Open first investigation <ChevronRight className="h-4 w-4" /></button></div></div>}
  </main>
}
